# Division d'entier (Question 5)
 
---

Auteur: Quentin Ducoulombier  
Date: 30/10/22  
Email: ducoulombi@cy-tech.fr

---

## Comment compiler ?

Pour compiler il suffit de se mettre dans le repertoire courant du fichier helloWorld.c

> gcc -Wall exo5.c -o exe  
> ./exe


## Comment generer Doxygen ?

Pour generer doxygen il existe deux solutions : 
La premiere manière

> doxygen -g
> doxygen Doxyfile

ou sinon 

> doxywizard

